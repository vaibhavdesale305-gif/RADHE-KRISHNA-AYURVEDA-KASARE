# Radhe Krishna Ayurveda Website
This website contains:
- index.html (main webpage)
- README.md (this file)

You can open index.html in any browser to view the website.
